from email.utils import format_datetime
import requests
from babel.dates import format_datetime

def hello():
    c = requests.get('https://api.github.com/repos/insper/dev-aberto/commits')
    info = c.json()
    commit_info = info[0]['commit']['author']
    commit_info['date'] = format_datetime(commit_info['date'], locale='pt_BR')
    return commit_info['date'], commit_info['name']
